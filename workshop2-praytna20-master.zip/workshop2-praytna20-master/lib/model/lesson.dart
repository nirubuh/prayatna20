// TODO Implement this library.
import 'package:praytna2/generated/i18n.dart';

class Lesson {
  String title;
  String level;
  double indicatorValue;
  int price;
  String content;
  String date;
  String time;
  String venue;

  Lesson(
      {this.title, this.level, this.indicatorValue, this.price, this.content ,this.date , this.time , this.venue});
}